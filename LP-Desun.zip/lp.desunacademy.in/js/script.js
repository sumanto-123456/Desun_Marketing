jQuery(document).ready(function($){

//   slider for  Projects we are proud of

// award-section slider
$('.js-award-image').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  dots: true,
  autoplaySpeed: 2000,
  arrows: true,
});

$('.js-client-tst-cont').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  asNavFor: '.js-client-tst-img'
});

$('.js-client-tst-img').slick({
  slidesToShow: 3, // Default for desktop
  slidesToScroll: 1,
  centerMode: true,
  centerPadding: '0px',
  asNavFor: '.js-client-tst-cont',
  dots: false,
  autoplay: false,
  autoplaySpeed: 2000,
  arrows: false,
  responsive: [
    {
      breakpoint: 768, // Tablet & mobile
      settings: {
        slidesToShow: 3,
      }
    }
  ]
});
});



// Function to update classes
//   fancybox
	if($("[data-fancybox]").length){ 
		Fancybox.bind("[data-fancybox]", {
	});
}

// logo slider

$('.js-logo-slider').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 0,
  arrows: false,
  dots: false,
  speed: 4000,
  pauseOnHover: false,
  cssEase: 'linear',
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 4
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2
      }
    }
  ]
});


  // onlode popup

  document.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
      var myModal = new bootstrap.Modal(document.getElementById('onLoadModal'));
      myModal.show();
    }, 8000); // 10,000 milliseconds = 10 seconds
  });
// on scroll tab
document.addEventListener('DOMContentLoaded', () => {
    const tabButtons = document.querySelectorAll('.tab-text-button');
    const tabContents = document.querySelectorAll('.tab-cont-wrap');
    let observer;
    let isScrolling = false;

    // Click to scroll
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        const tabId = button.getAttribute('data-tab');
        const target = document.getElementById(`tab-${tabId}`);

        if (target) {
          isScrolling = true;

          // Remove active from all
          tabButtons.forEach(btn => btn.classList.remove('active'));
          // Set clicked one active
          button.classList.add('active');

          // Scroll with GSAP
          gsap.to(window, {
            duration: 0.8,
            scrollTo: {
              y: target,
              offsetY: 100
            },
            ease: "power2.out",
            onComplete: () => {
              // Wait a bit to ensure scroll settled
              setTimeout(() => isScrolling = false, 200);
            }
          });
        }
      });
    });

    // Observer for scroll-based active state
    observer = new IntersectionObserver((entries) => {
      if (isScrolling) return; // Skip during scroll animation

      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const tabId = entry.target.id.split('-')[1];
          tabButtons.forEach(btn => btn.classList.remove('active'));
          const activeBtn = document.querySelector(`.tab-text-button[data-tab="${tabId}"]`);
          if (activeBtn) activeBtn.classList.add('active');
        }
      });
    }, {
      root: null,
      rootMargin: '-20% 0px -90% 0px',
      threshold: 0
    });

    tabContents.forEach(section => observer.observe(section));
  });






  




/* Enroll form */

const forms = document.querySelectorAll(".enrollForm");

let handleEnroll = () => {

  forms.forEach((form) => {

    form.classList.add("hightlightForm");

    form.querySelector(".name").classList.add("highlightInput");

  });

  setTimeout(() => {

    forms.forEach((form) => {

      form.classList.remove("hightlightForm");

      form.querySelector(".name").classList.remove("highlightInput");

    });

  }, 2000);

};

forms.forEach((form) => {

  const nameInput = form.querySelector(".name");

  const emailInput = form.querySelector(".email");

  const numberInput = form.querySelector(".number");

  const selectInput = form.querySelector(".select");

  const nameError = form.querySelector(".nameError");

  const emailError = form.querySelector(".emailError");

  const numberError = form.querySelector(".numberError");

  const selectError = form.querySelector(".selectError");

  // Function to validate name

  function validateName() {

    const name = nameInput.value.trim();

    const namePattern = /^[A-Za-z ]+$/;

    if (name === "") {

      nameError.textContent = "Name is required";

      return false;

    } else if (!namePattern.test(name)) {

      nameError.textContent = "Invalid name format";

      return false;

    } else {

      nameError.textContent = "";

      return true;

    }

  }

  // Function to validate email

  function validateEmail() {

    const email = emailInput.value.trim();

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email === "") {

      emailError.textContent = "Email is required";

      return false;

    } else if (!emailPattern.test(email)) {

      emailError.textContent = "Invalid email format";

      return false;

    } else {

      emailError.textContent = "";

      return true;

    }

  }

  // Function to validate number

  function validateNumber() {

    const number = numberInput.value.trim();

    const numberPattern = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

    if (number === "") {

      numberError.textContent = "Number is required";

      return false;

    } else if (!numberPattern.test(number)) {

      numberError.textContent = "Invalid number format";

      return false;

    } else {

      numberError.textContent = "";

      return true;

    }

  }

  // Function to validate select

  function validateSelect() {

    if (selectInput.value === "") {

      selectError.textContent = "Please select an option";

      return false;

    } else {

      selectError.textContent = "";

      return true;

    }

  }

  // Validate on input

  nameInput.addEventListener("input", validateName);

  emailInput.addEventListener("input", validateEmail);

  numberInput.addEventListener("input", validateNumber);

  selectInput.addEventListener("change", validateSelect);


  // Validate on form submit

  form.addEventListener("submit", function (event) {

    // Prevent form submission if validation fails

    if (

      !validateName() ||

      !validateEmail() ||

      !validateNumber() ||

      !validateSelect()

    ) {

      event.preventDefault();

    } else {

      event.preventDefault();

      // send data to server

      const formData = new FormData();

      formData.append('name', nameInput.value);

      formData.append('email', emailInput.value);

      formData.append('mobile_number', numberInput.value);

      formData.append('field_of_study', selectInput.value);

      formData.append('url', 'https://ex.desunacademy.in/');

      formData.append('recived_mail',  document.getElementById('recived_mail').value);

	  formData.append('success_url', document.getElementById('success_url').value);

	  formData.append('mail_subject', document.getElementById('mail_subject').value);
	  
	  // attach utm source
      const urlParams = new URLSearchParams(window.location.search);
      formData.append('utm_source', urlParams.get('utm_source'));
      formData.append('utm_medium', urlParams.get('utm_medium'));
      formData.append('utm_campaign', urlParams.get('utm_campaign'));


      fetch('https://ehostingguru.com/desuntech-email/api.php', {

        method: "POST",

        body: formData

      })

      .then( res => res.json() )

      .then( res => {

        window.location.href = document.getElementById('success_url').value; 

      })

      .catch( err => {

        console.log(err)

      });
    

       // Clear input fields

       nameInput.value = "";

       emailInput.value = "";

       numberInput.value = "";

       selectInput.value = "";


      handleEnroll();

    }

  });

});

/* Enroll form */

/* Accordian */

  function handleAccordion(button) {
      const content = button.nextElementSibling; // Get the associated content
      const indicator = button.querySelector(".indicator");

      // Toggle the current accordion
      if (content.classList.contains("hidden")) {
          // Expand the accordion
          content.classList.remove("hidden"); // Show content
          indicator.textContent = "-"; // Update the indicator
          button.classList.remove("text-gray-500"); // Remove default color
          button.classList.add("text-[#82c600]"); // Highlight text
      } else {
          // Collapse the accordion
          content.classList.add("hidden"); // Hide content
          indicator.textContent = "+"; // Reset the indicator
          button.classList.remove("text-[#82c600]"); // Remove highlight
          button.classList.add("text-gray-500"); // Set back to default
      }
  }

  // Function to initialize the accordion state
  function initializeAccordion() {
      const accordions = document.querySelectorAll(".accordion-btn");
      accordions.forEach((button, index) => {
          const content = button.nextElementSibling;
          const indicator = button.querySelector(".indicator");

          // Set default styles for all accordion headers
          button.classList.add("text-gray-500"); // Default text color
          button.classList.remove("text-[#82c600]"); // Ensure no highlight

          if (index === 0) {
              // Open the first accordion by default
              content.classList.remove("hidden");
              indicator.textContent = "-";
              button.classList.remove("text-gray-500"); // Remove default color
              button.classList.add("text-[#82c600]"); // Highlight the first accordion
          } else {
              // Close all other accordions
              content.classList.add("hidden");
              indicator.textContent = "+";
          }
      });
  }

  // Call the function on page load
  window.onload = initializeAccordion;

/* Accordian */

/* Modal */

document.addEventListener("DOMContentLoaded", function () {
    const readMoreLinks = document.querySelectorAll(".read-more");
    const modalTitle = document.getElementById("readMoreModalLabel");
    const modalDescription = document.getElementById("modalDescription");
    const modalTopics = document.getElementById("modalTopics");

    readMoreLinks.forEach(link => {
        link.addEventListener("click", function () {
            // Get data attributes
            const title = this.getAttribute("data-title");
            const description = this.getAttribute("data-description");
            const topics = this.getAttribute("data-topics").split(", ");

            // Update modal content
            modalTitle.textContent = title;
            modalDescription.textContent = description;
            modalTopics.innerHTML = ""; // Clear previous topics

            topics.forEach(topic => {
                const listItem = document.createElement("li");
                listItem.innerHTML = `<i class="fas fa-check-circle me-2"></i> ${topic}`;
                modalTopics.appendChild(listItem);
            });
        });
    });
});

/* Modal */

/* FAQ */

function showContent(sectionId) {
    // First, close all questions and reset styles in all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.add('hidden'); // Hide all sections
        const allQuestions = section.querySelectorAll('.accordion');
        const allButtons = section.querySelectorAll('.accordion-btn');
        const allContents = section.querySelectorAll('.accordion-content');
        const allIndicators = section.querySelectorAll('.indicator');

        allButtons.forEach(btn => btn.classList.remove('text-green-700')); // Reset all button colors
        allContents.forEach(content => content.classList.add('hidden')); // Hide all contents
        allIndicators.forEach(indicator => indicator.textContent = '+'); // Reset all indicators
    });

    // Show the selected section
    const activeSection = document.getElementById(sectionId);
    activeSection.classList.remove('hidden');

    // Reset sidebar button styles
    const sidebarButtons = document.querySelectorAll('.sidebar-container button');
    sidebarButtons.forEach(button => button.classList.remove('shadow-md', 'active-section', 'text-green-700'));
    document.getElementById(`${sectionId}-btn`).classList.add('shadow-md', 'active-section', 'text-green-700');

    // Open the first question in the active section
    const firstAccordion = activeSection.querySelector('.accordion');
    if (firstAccordion) {
        const firstContent = firstAccordion.querySelector('.accordion-content');
        const firstButton = firstAccordion.querySelector('.accordion-btn');
        const firstIndicator = firstButton.querySelector('.indicator');

        firstContent.classList.remove('hidden'); // Open the first question
        firstButton.classList.add('text-green-700'); // Set the color to green for the first question
        firstIndicator.textContent = '-'; // Change the indicator to '-'
    }

    const allQuestions = activeSection.querySelectorAll('.accordion');
    const showMoreBtn = activeSection.querySelector('.show-more-btn');

    if (allQuestions.length > 5) {
        // Initially, hide questions beyond the 5th
        allQuestions.forEach((question, index) => {
            if (index >= 5) question.classList.add('hidden');
        });
        showMoreBtn.classList.remove('hidden');
    } else {
        showMoreBtn.classList.add('hidden');
    }
}

function toggleAccordion(button) {
    const content = button.nextElementSibling;
    const indicator = button.querySelector('.indicator');

    // Check if the clicked accordion is already open
    if (!content.classList.contains('hidden')) {
        // Close the currently open accordion
        content.classList.add('hidden'); // Hide content
        button.classList.remove('text-green-700'); // Reset button color to default
        indicator.textContent = '+'; // Reset indicator to '+'
        return; // Stop further execution
    }

    // If not already open, close all other accordions in the section
    const section = button.closest('.content-section');
    const allButtons = section.querySelectorAll('.accordion-btn');
    const allContents = section.querySelectorAll('.accordion-content');
    const allIndicators = section.querySelectorAll('.indicator');

    allButtons.forEach(btn => btn.classList.remove('text-green-700')); // Remove green color from all buttons
    allContents.forEach(content => content.classList.add('hidden')); // Hide all contents
    allIndicators.forEach(indicator => indicator.textContent = '+'); // Reset all indicators to '+'

    // Open the clicked accordion item
    content.classList.remove('hidden'); // Show content
    button.classList.add('text-green-700'); // Set button text color to green
    indicator.textContent = '-'; // Change indicator to '-'
}

function toggleShowMore(button) {
    const accordionGroup = button.previousElementSibling;
    const allQuestions = accordionGroup.querySelectorAll('.accordion');
    const hiddenQuestions = accordionGroup.querySelectorAll('.accordion.hidden');

    if (hiddenQuestions.length) {
        // Show all questions
        allQuestions.forEach(question => question.classList.remove('hidden'));
        button.textContent = 'Show Less';
    } else {
        // Hide questions after the 5th one
        allQuestions.forEach((question, index) => {
            if (index >= 5) question.classList.add('hidden');
        });
        button.textContent = 'Show More';
    }
}

// Call this to open the first section and ensure the first accordion is open by default
showContent('bootcamp');

/* FAQ */

/* Disclaimer */

// JavaScript for Read More/Less toggle
  const toggleButton = document.getElementById('toggle-button');
  const extraText = document.getElementById('extra-text');

  toggleButton.addEventListener('click', () => {
      const isHidden = extraText.classList.contains('hidden');
      extraText.classList.toggle('hidden', !isHidden);
      toggleButton.textContent = isHidden ? 'Read Less' : 'Read More';
  });

/* Disclaimer */

/* Tuition Fee script */

document.addEventListener("DOMContentLoaded", () => {
      const tabs = document.querySelectorAll(".tab");
      const tabContents = document.querySelectorAll(".tab-content");

      // Ensure the first tab is active by default
      if (tabs.length > 0) {
          tabs[0].classList.add("active", "text-green-700", "border-green-700");
      }
      if (tabContents.length > 0) {
          tabContents[0].classList.remove("hidden");
      }

      // Add event listeners to tabs
      tabs.forEach(tab => {
          tab.addEventListener("click", () => {
              tabs.forEach(t => t.classList.remove("active", "text-green-700", "border-green-700"));
              tabContents.forEach(content => content.classList.add("hidden"));

              tab.classList.add("active", "text-green-700", "border-green-700");
              document.getElementById(tab.dataset.tab).classList.remove("hidden");
          });
      });
});

/* Tuition Fee script */

/* Tab */

// Select all buttons and the content section
  const buttons = document.querySelectorAll('.tab-btn');
  const contentSection = document.getElementById('contents-section');

  // Function to clear active states
  function clearActiveStates() {
      buttons.forEach(button => {
          button.classList.remove('active-side');
      });
  }

  // Event listener for NSDC Certification button
  document.getElementById('nsdc-btn').addEventListener('click', () => {
      clearActiveStates();
      document.getElementById('nsdc-btn').classList.add('active-side');
      contentSection.innerHTML = `
  <div class="flex items-center space-x-4">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="green" width="20"
    height="20">
    <path
        d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-111 111-47-47c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l64 64c9.4 9.4 24.6 9.4 33.9 0L369 209z" />
</svg>
    <p class="text-gray-700">
      Receive the NSDC Certification recognised by the Indian Government, enhancing your employability and career prospects.
    </p>
  </div>
  <div class="mt-4 xs:w-full xs:h-187px md:w-700px md:h-400">
    <img src="./images/NSDC.webp" alt="NSDC Certificate" class="w-full rounded-lg shadow-lg border border-gray-200">
  </div>
`;
  });

  // Event listener for Mentorship Certificate button
  document.getElementById('mentorship-btn').addEventListener('click', () => {
      clearActiveStates();
      document.getElementById('mentorship-btn').classList.add('active-side');
      contentSection.innerHTML = `
  <div class="flex items-start space-x-4">
    <p class="text-gray-700 font-semibold">
      Gain hands-on experience and demonstrate your practical expertise with a Mentorship Certificate based on real-world projects.
    </p>
  </div>
  <div class="mt-4 xs:w-full xs:h-187px md:w-700px md:h-400">
    <img src="./images/sample_certificate.png" alt="Mentorship Certificate" class="w-full rounded-lg shadow-lg border border-gray-200">
  </div>
`;
  });

/* Tab */

/* Data Side */

function showActiveContent(sectionId) {
      // First, close all questions and reset styles in all sections
      const sections = document.querySelectorAll('.data-side-section');
      sections.forEach(section => {
          section.classList.add('hidden'); // Hide all sections
          const allButtons = section.querySelectorAll('.accordion-btn');
          const allContents = section.querySelectorAll('.accordion-content');
          const allIndicators = section.querySelectorAll('.indicator');

          allButtons.forEach(btn => btn.classList.remove('text-green-700')); // Reset all button colors
          allContents.forEach(content => content.classList.add('hidden')); // Hide all contents
          allIndicators.forEach(indicator => indicator.textContent = '+'); // Reset all indicators
      });

      // Show the selected section
      const activeSection = document.getElementById(sectionId);
      activeSection.classList.remove('hidden');

      // Reset sidebar button styles
      const sidebarButtons = document.querySelectorAll('.sidemenu-container button');
      sidebarButtons.forEach(button => button.classList.remove('shadow-md', 'active-section-Id', 'text-green-700'));
      document.getElementById(`${sectionId}-id`).classList.add('shadow-md', 'active-section-Id', 'text-green-700');

      if (firstAccordion) {
          const firstIndicator = firstButton.querySelector('.indicator');

          firstContent.classList.remove('hidden'); // Open the first question
          firstButton.classList.add('text-green-500'); // Set the color to green for the first question
      }
}
showActiveContent('prerequisites');  // Call this to open the first section by default

/* Data Side */

/* Toggler */

function toggleSection(id) {
      const content = document.getElementById(`content-${id}`);
      const icon = document.getElementById(`icon-${id}`);

      if (content.classList.contains("hidden")) {
          content.classList.remove("hidden");
          icon.classList.add("rotate-180");
      } else {
          content.classList.add("hidden");
          icon.classList.remove("rotate-180");
      }
}

/* Toggler */



