/*---------------------------- OWL-CAROUSEL -------------------------------*/

$(document).ready(function(){
     $("#js_testimonials").owlCarousel({
        loop: true,
        margin: 10,
        dots: true,
        nav: false,
        autoplay: true,
        stagePadding: 80,
        center: true,
        responsive: {
            0: { items: 1,
                 stagePadding: 0,
             },
            576: { items: 1,
                   stagePadding: 0,
             },
            768: { items: 1,
                   stagePadding: 30,
             },
            992: { items: 1 },
        },
    });
    
    $("#js_reviews").owlCarousel({
        loop: true,
        margin: 20,
        dots: true,
        nav: false,
        autoplay: true,
        responsive: {
            0: { items: 1 },
            768: { items: 2 },
            992: { items: 3 },
        },
    });

    $("#js_respect").owlCarousel({
        loop: true,
        margin: 20,
        dots: false,
        nav: true,
        autoplay: false,
        responsive: {
            0: { items: 1 },
            768: { items: 1 },
            992: { items: 1 },
        },
    });
});

/*---------------------------- OWL-CAROUSEL -------------------------------*/